﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Platform.Core.UI;
using WeifenLuo.WinFormsUI.Docking;

namespace FirstPlugin
{
    public partial class FirstTreeView : BaseForm
    {
        public FirstTreeView()
        {
            InitializeComponent();
        }
    }
}
